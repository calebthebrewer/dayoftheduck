//global vars
var min_height,
	content_min_height,
	min_width = 600,
	c_height,
	anim_d = 300,
	anim = {duration: anim_d, queue: false };
//resize website
function resize() {
	//width
	$("#content").width( $(window).width()-325 );
	//height
	resize_height();
}
function resize_height(height_diff) {
	if( !height_diff ) {
		height_diff = 0;
	}
	//move menu
	if( $("#side-bar-wrap").height()+28<$("#side-bar").height() ) {
		$("#side-bar-wrap").css( {
			top: $("#side-bar").height()-(min_height+28),
			position: "fixed"
		}, anim_d );
	} else {
		$("#side-bar-wrap").css( {
			top: "0",
			position: "relative"
		}, anim_d );
	}
	//move content
	if( ($("#content").height()+56)+height_diff<$("#container").height() ) {
		$("#content").animate( {
			top: $("#container").height()-(($("#content").height()+56)+height_diff)
		}, anim );
	} else {
		$("#content").animate( {
			top: "0"
		}, anim );
	}
}
function toggle_time() {
	if( $("#container").hasClass('night-on') ) {
		$("#container").switchClass('night-on', 'night-off');
		$("#lights-status").switchClass('lights-on', 'lights-off');
	} else {
		$("#container").switchClass('night-off', 'night-on');
		$("#lights-status").switchClass('lights-off', 'lights-on');
	}
}
function toggle_article(article) {
	if( $(article).find('.content').is(":visible") ) {
        $(article).find('.content').animate( {
    			opacity: "0"
	    	}, anim_d, function() {
	    		resize_height(($(article).find('.excerpt-wrap').height()-$(article).find('.content-wrap').height()-10));
	    		$(article).find('.content-wrap').slideUp( anim_d );
		    	$(article).find('.excerpt-wrap').slideDown( anim_d, function(){
		            $(article).find('.excerpt').animate( {
		            	opacity: "1"            	
		            }, anim );
		        });
	    	});
    } else {
    	$(article).find('.excerpt').animate( {
    			opacity: "0"
	    	}, anim_d, function() {
	    		resize_height(($(article).find('.content-wrap').height())-$(article).find('.excerpt-wrap').height()+10);
	    		$(article).find('.excerpt-wrap').slideUp( anim_d );
		    	$(article).find('.content-wrap').slideDown( anim_d, function(){
		    	//	resize();
		            $(article).find('.content').animate( {
		            	opacity: "1"
		            }, anim );
		        });	
	    	});
	}
	resize();
}
//document ready stuff
jQuery(document).ready(function($) {
	//reset min_height
	min_height = $("#side-bar-wrap").height();
	content_min_height = $("#content").height();
	//bind and run resize
	$.event.add( window, "resize", resize );
	resize();
	//bind tile click
	$("#content .toggleable").click(function() {
		if( $(this).siblings().find('.content').is(":visible") ) {
			toggle_article( $(this).siblings().find('.content:visible').parent().parent().parent() );
		} else {
			toggle_article( this );
		}
		
		
		/*
		if( $(article).find('.content').is(":visible") ) {
	        $(article).find('.content').animate( {
	    			opacity: "0"
		    	}, anim_d, function() {
		    		resize_height(($(article).find('.excerpt-wrap').height()-$(article).find('.content-wrap').height())-10);
		    		$(article).find('.content-wrap').slideUp( anim_d );
			    	$(article).find('.excerpt-wrap').slideDown( anim_d, function(){
			            $(article).find('.excerpt').animate( {
			            	opacity: "1"            	
			            }, anim );
			        });
		    	});
	    } else {
	    	//close siblings
	    	if( $(this).siblings().find('.content').is(":visible") ) {
	    		sibling = $(this).siblings().find('.content').parent().parent();
	    		$(sibling).find('.content').animate( {
		    			opacity: "0"
			    	}, anim_d, function() {
			    		resize_height(($(sibling).find('.excerpt-wrap').height()-$(sibling).find('.content-wrap').height())-10);
			    		$(sibling).find('.content-wrap').slideUp( anim_d );
				    	$(sibling).find('.excerpt-wrap').slideDown( anim_d, function(){
				  //  		resize();
				            $(sibling).find('.excerpt').animate( {
				            	opacity: "1"
				            }, anim );
				        });	
			    	});
	    	}
	    	$(article).find('.excerpt').animate( {
	    			opacity: "0"
		    	}, anim_d, function() {
		 //   		resize_height(($(article).find('.content-wrap').height())-$(article).find('.excerpt-wrap').height());
		    		$(article).find('.excerpt-wrap').slideUp( anim_d );
			    	$(article).find('.content-wrap').slideDown( anim_d, function(){
			    		resize();
			            $(article).find('.content').animate( {
			            	opacity: "1"
			            }, anim );
			        });	
		    	});
	    } */
	});
	//time control
	function time_control() {
		time = new Date();
		time = time.getHours();
		if( time > 9 && time < 17 ) {
			$("#container").switchClass('night-on', 'night-off');
			$("#lights-status").switchClass('lights-on', 'lights-off');
		}
	}
	time_control();
});
