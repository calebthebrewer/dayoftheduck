<?php $options = get_option( 'duck_theme_options' ); ?>
<div id="side-bar">
	<div id="side-bar-wrap">
		<div id="branding">
			<a href="<?php bloginfo( 'url' ); ?>" title="<?php get_bloginfo( 'name') ?> Home">
			<?php
				if( isset($options['branding']['id']) ) {
					echo wp_get_attachment_image(
						$options['branding']['id'], 
						array( '320', 'auto' )
					);
				}
			?>
			</a>
		</div>
		<nav id="main-navagation">
			<?php wp_nav_menu( 'main-menu' ); ?>
		</nav>
	</div><!-- #side-bar-wrap -->
</div><!-- #side-bar -->