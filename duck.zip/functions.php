<?php
//add theme options page
add_action('admin_menu', 'duck_admin_menu_functions');
function duck_admin_menu_functions() {
	//add media uploader support
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_enqueue_style('thickbox');
	//add sub menus
	add_submenu_page( 'themes.php', 'Theme Options', 'Theme Options', 'edit_theme_options', 'duck-theme-options', 'duck_theme_options' );
}
//add menu support
add_theme_support( 'menus' );
register_nav_menus( array(
	'main-menu' => 'Main Menu'
) );
//add featured image support
add_theme_support( 'post-thumbnails' );
//add scripts
//add_action( 'wp_enqueue_scripts', 'duck_enqueue_scripts' );
function duck_enqueue_scripts() {
	wp_register_script( 'duck-js', get_site_url().'/js/main.js' );
	wp_enqueue_script( 'duck-js' );
}
//theme options hooks
add_action( 'wp_ajax_duck_theme_options_ajax_action', 'duck_theme_options_ajax_callback' );
add_action( 'after_setup_theme', 'duck_theme_options_initialization' );
/*
 * Theme Options Display Function
 */
 if( !function_exists( 'duck_theme_options' ) ) {
	function duck_theme_options() {
		$options = get_option( 'duck_theme_options' );
	?>
		<div id="duck-theme-options-wrap">
			<div class="icon32" id="icon-tools"><br /></div>
			<h2>Theme Options</h2>
			<p><i>From here you can modify different settings for this theme.</i></p>
			<section id="branding">
				<h3>Branding</h3>
				<img id="duck-logo-src" src="<?php echo isset($options['branding'] ) ? $options['branding']['src'] : ''; ?>"><br>
				<input type="hidden" id="duck-logo-id" value="<?php echo isset($options['branding'] ) ? $options['branding']['id'] : ''; ?>">
				<input type="button" id="duck-logo-change" value="Set Image">
				<input type="button" id="duck-logo-remove" value="Remove Image">
			</section>
		</div>
			<div>
				<p class="submit"><input id="save-changes-btn" name="Submit" type="submit" class="button-primary" value="<?php esc_attr_e('Save Changes'); ?>"></p>
				<h2 id="ajax-response-field" style="text-align: left"></h2>
			</div>
		</div>
		<script type="text/javascript">
		jQuery(function($) {
			//handle image edit
			$(document).on("click", "#duck-logo-change", function() { // button
				formfield = 'add image';
				tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
				return false;
			});
			window.send_to_editor = function(html) {
				var imgurl = $('img',html).attr('src');
				var imgid = $('img', html).attr('class');
				imgid = imgid.replace(/(.*?)wp-image-/, '');
				tb_remove();
				$("#duck-logo-src").attr( 'src', imgurl ); // image preview
				$("#duck-logo-id").val(imgid); // hidden id
			}
			$(document).mouseup(function(e) {
			    if ( $("#TP_iframeContent").has(e.target).length === 0 ) {
					tb_remove();
			    }
			});
			$(document).on("click", "#duck-logo-remove", function() { // button
				$("#duck-logo-src").attr('src', '');
				$("#duck-logo-id").val('');
			});
			//handle save
			$("#save-changes-btn").click(function() {
				$("#save-changes-btn").val( 'Saving...' );
				//send ajax request to update
				var data = { 
					action: 'duck_theme_options_ajax_action',
					duck_theme_options: { branding: { src: $("#duck-logo-src").attr('src'), id: $("#duck-logo-id").val() } }
				};
				$.post(ajaxurl, data, function( msg ) {
					$("#save-changes-btn").val( msg );
				});
			});
		});
		</script>
	<?php }
}
/*
 * Theme Option Save
 */
if( !function_exists( 'duck_theme_options_ajax_callback' ) ) {
	function duck_theme_options_ajax_callback() {
		global $wpdb; // this is how you get access to the database
		update_option( 'duck_theme_options', $_POST['duck_theme_options'] );
		echo 'Changes Saved'; // save confirmation
		exit(); // this is required to return a proper result
	}
}
/*
 * Theme Options Initialization
 */
if( !function_exists( 'duck_theme_options_initialization' ) ) {
	function duck_theme_options_initialization() {
//		add_option( $option_name, $value, ' ', 'no' );
	}
}
?>